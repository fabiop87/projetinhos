<?php

session_start();

$id = $_GET['id'];

require_once('./Models/Animes.php');

$Anime = new Anime();

$anime = $Anime->getAnime($id);

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="/resources/bootstrap.min.css">
    <link rel="stylesheet" href="/resources/jhonsons.css">
</head>

<body>
    <div class="container">
        <div class="row">

            <h2 class="text-center"><?php echo $anime["nome"]; ?></h2>

            <img src="<?php echo $anime["imagem"]; ?>" class="img" height="600" width="600" alt="Imagem do Anime">

            <p><?php echo $anime["sinopse"]; ?></p>
            <p>Número de episódios: <?php echo $anime["num_episodios"]; ?></p>
            <p>Status: <?php echo $anime["status"]; ?></p>
            <p>Estreia: <?php echo $anime["estreia"]; ?></p>
            <p>Gênero: <?php echo $anime["genero"]; ?></p>

        </div>
    </div>

    <a href="dashboard.php" class="btn btn-primary">Voltar</a>
</body>

</html>