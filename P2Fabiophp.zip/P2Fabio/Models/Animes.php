<?php
require_once('conexao.php');

class Anime extends conexao
{

    public function create($nome, $sinopse, $num_episodios, $status, $estreia, $genero, $imagem)
    {
        $sql = "INSERT INTO animes (nome, sinopse, num_episodios, status, estreia, genero, imagem) VALUES (:nome, :sinopse, :num_episodios, :status, :estreia, :genero, :imagem)";
        $stmt = $this->getPDO()->prepare($sql);
        $stmt->bindParam(":nome", $nome);
        $stmt->bindParam(":sinopse", $sinopse);
        $stmt->bindParam(":num_episodios", $num_episodios);
        $stmt->bindParam(":status", $status);
        $stmt->bindParam(":estreia", $estreia);
        $stmt->bindParam(":genero", $genero);
        $stmt->bindParam(":imagem", $imagem);

        if ($stmt->execute()) {
            $id = $this->getPDO()->lastInsertId();

            if (!empty($_FILES["imagem"]["name"])) {
                $caminho_imagem = "../imagens/" . $id . "_" . $_FILES["imagem"]["name"];

                if (move_uploaded_file($_FILES["imagem"]["tmp_name"], $caminho_imagem)) {
                    $sql = "UPDATE animes SET imagem = :imagem WHERE id = :id";
                    $stmt = $this->getPDO()->prepare($sql);
                    $stmt->bindParam(":imagem", $caminho_imagem);
                    $stmt->bindParam(":id", $id);
                    $stmt->execute();
                }
            }
        }
    }

    public function delete($id)
    {
        $sql = "DELETE FROM animes WHERE id = :id";

        $stmt = $this->getPDO()->prepare($sql);
        $stmt->bindParam(':id', $id);

        return $stmt->execute();
    }


    public function update($id, $nome, $sinopse, $num_episodios, $status, $estreia, $genero)
    {
        $sql = "UPDATE animes SET nome = :nome, sinopse = :sinopse, num_episodios = :num_episodios, status = :status, estreia = :estreia, genero = :genero";

        // Adiciona a cláusula WHERE somente se o valor de $id estiver definido
        if (isset($id)) {
            $sql .= " WHERE id = :id";
        }

        $stmt = $this->getPDO()->prepare($sql);
        $stmt->bindParam(":nome", $nome);
        $stmt->bindParam(":sinopse", $sinopse);
        $stmt->bindParam(":num_episodios", $num_episodios);
        $stmt->bindParam(":status", $status);
        $stmt->bindParam(":estreia", $estreia);
        $stmt->bindParam(":genero", $genero);

        // Adiciona o parâmetro :id somente se o valor de $id estiver definido
        if (isset($id)) {
            $stmt->bindParam(":id", $id);
        }

        if (!empty($_FILES["imagem"]["name"])) {
            $caminho_imagem = "../imagens/" . $id . "_" . $_FILES["imagem"]["name"];

            if (move_uploaded_file($_FILES["imagem"]["tmp_name"], $caminho_imagem)) {
                $sql2 = "UPDATE animes SET imagem = :imagem WHERE id = :id";
                $stmt2 = $this->getPDO()->prepare($sql2);
                $stmt2->bindParam(":imagem", $caminho_imagem);
                $stmt2->bindParam(":id", $id);
                $stmt2->execute();
            }
        }
    }

    public function readAll()
    {
        $sql = "SELECT * FROM animes";
        $stmt = $this->getPDO()->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getAnime($id)
    {
        $sql = "SELECT * FROM animes WHERE id = '$id'";
        $stmt = $this->getPDO()->prepare($sql);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
