// Fabio Pilon 0391/22-1
let form = document.querySelector('form');
let cpf = document.getElementById('cpf');
let email = document.getElementById('email');
let nome = document.getElementById('nome');
let senha = document.getElementById('senha');
let csenha = document.getElementById('csenha');
let textoForm = document.getElementById('textoForm');
let textoNome = document.getElementById('textoNome');
let textoCpf = document.getElementById('textoCpf');
let textoEmail = document.getElementById('textoEmail');
let textoSenha = document.getElementById('textoSenha');
let textoSenha2 = document.getElementById('textoSenha2');

form.addEventListener('submit', (e) => {
  if (cpf.value == "" && nome.value.trim() == "" && email.value == "" && senha.value == "" && csenha.value == "" || !validaCPF() || !verificarSegundaSenha()) {
    textoForm.textContent = "Preencha todos os campos ou as senhas estão diferentes";
  } else if (
    validatorEmail(email.value) === true &&
    validatorSenha(senha.value) === true
  ) {
    // console.log(email.value);
    // console.log(senha.value);
    textoForm.textContent = "";
    textoEmail.textContent = "";
    textoSenha.textContent = "";
  } else {
    console.log("Requisição não atendida");
  }

  e.preventDefault();
});


function validaCPF() {
  var vcpf = cpf.value;
  //console.log(vcpf);
  var Soma = 0
  var Resto

  var strCPF = String(vcpf).replace(/[^\d]/g, '')

  if (strCPF.length !== 11)
    return false

  if ([
    '00000000000',
    '11111111111',
    '22222222222',
    '33333333333',
    '44444444444',
    '55555555555',
    '66666666666',
    '77777777777',
    '88888888888',
    '99999999999',
  ].indexOf(strCPF) !== -1)

    return false

  for (i = 1; i <= 9; i++)
    Soma = Soma + parseInt(strCPF.substring(i - 1, i)) * (11 - i);

  Resto = (Soma * 10) % 11

  if ((Resto == 10) || (Resto == 11))
    Resto = 0

  if (Resto != parseInt(strCPF.substring(9, 10)))
    return false

  Soma = 0

  for (i = 1; i <= 10; i++)
    Soma = Soma + parseInt(strCPF.substring(i - 1, i)) * (12 - i)

  Resto = (Soma * 10) % 11

  if ((Resto == 10) || (Resto == 11))
    Resto = 0

  if (Resto != parseInt(strCPF.substring(10, 11)))
    return false

  return true
}

function testarOcpf(){
  if (!validaCPF()) {
    textoCpf.textContent = "O cpf nao está certo meu consagrado, verifica ai";
  }else{
    textoCpf.textContent = "";
  }
}

function validaNome() {
  if (nome.value.trim() == "") {
    textoNome.textContent = "Campo não pode ficar vazio";
    return false;
  }
  else {
    textoNome.textContent = "";
    return true;

  }
}


email.addEventListener("keyup", () => {
  if (validatorEmail(email.value) !== true) {
    textoEmail.textContent = "O formato do email deve ser Ex: name@abc.com";
  } else {
    textoEmail.textContent = "";
  }
});

senha.addEventListener("keyup", () => {
  if (validatorSenha(senha.value) !== true) {
    textoSenha.textContent =
      "O formato da senha deve ser no min 6 caracteres";
  } else {
    textoSenha.textContent = "";
  }
});

function validatorEmail(email) {
  let emailPattern =
    /^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/;
  return emailPattern.test(email);
}

function validatorSenha(senha) {
  let senhaPattern =
    /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/;
  return senhaPattern.test(senha);
}


function verificarSegundaSenha() {
  if (senha.value != csenha.value) {
    textoSenha2.textContent = "as senhas nao correspondem";
    return false
  } else {
    return true
  }
}