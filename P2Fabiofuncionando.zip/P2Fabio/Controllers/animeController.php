<?php
if (!isset($_POST['requisicao'])) {
    header('location:/?error=sapato');
    return false;
}
var_dump($_POST);

require_once('../Models/Animes.php');
$anime = new Anime();

switch ($_POST['requisicao']) {
    case 'create':
        $anime->create(
            $_POST["nome"],
            $_POST["sinopse"],
            $_POST["num_episodios"],
            $_POST["status"],
            $_POST["estreia"],
            $_POST["genero"],
            $_FILES["imagem"]["name"]
        );
        break;
    case 'delete':
        $anime->delete($_POST['id']);
        break;
    case 'update':
        $anime->update(
            $_POST['id'],
            $_POST["nome"],
            $_POST["sinopse"],
            $_POST["num_episodios"],
            $_POST["status"],
            $_POST["estreia"],
            $_POST["genero"],
            $_FILES["imagem"]["name"]
        );
        break;

    default:
        die('calma que deu merda');
        break;
}

header("Location: ../dashboard.php");
